package net.hedtech.restfulapi

class Child {
    String name

    static constraints = {
    }
}